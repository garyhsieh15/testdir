
import numpy as np
import math
import matplotlib.pyplot as plt

from sympy import *

import draw_func as dfc

if __name__ == "__main__":
    print("enter main function")

    dfc.theo_sol()
